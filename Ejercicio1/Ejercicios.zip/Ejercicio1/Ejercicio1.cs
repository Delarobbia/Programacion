﻿// See https://aka.ms/new-console-template for more information
//Pido el nombre y lo recibo
Console.WriteLine("Cual es tu nombre?");
String nombre = Console.ReadLine();
//Imprimo el nombre
Console.WriteLine("Tu nombre es: " + nombre);
