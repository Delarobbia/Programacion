﻿// See https://aka.ms/new-console-template for more information
//Preguntamos la hora
Console.WriteLine("Que hora es?");
string hora = Console.ReadLine();
//Imprimimos la hora
Console.WriteLine("Son las: "+hora);
